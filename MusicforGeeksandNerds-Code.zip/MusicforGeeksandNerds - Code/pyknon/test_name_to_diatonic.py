from unittest import TestCase

__author__ = 'kroger'


class TestName_to_diatonic(TestCase):
    def test_name_to_diatonic(self):
        self.fail()